#ifndef EF_H
#define EF_H

#include <string.h>

const char* find_embedded_file(const char* name, size_t* size);

#endif
