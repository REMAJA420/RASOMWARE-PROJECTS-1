#ifndef RANDOM_H
#define RANDOM_H

uint8_t* advandedRNG(char* &id, unsigned int &len, unsigned int seed);

#endif
